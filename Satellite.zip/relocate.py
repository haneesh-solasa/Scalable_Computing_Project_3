import argparse
import pandas as pd
from statsmodels.tsa.statespace.sarimax import SARIMAX

parser = argparse.ArgumentParser()
parser.add_argument('--loc', help='Ship location', type=str)
parser.add_argument('--day', help='Day', type=int)
parser.add_argument('--time', help='Time', type=int)
parser.add_argument('--cells', help='Preferred cell order', type=list)
args = parser.parse_args()

weather21 = pd.read_csv("2021.csv", header=0)
weather22 = pd.read_csv("weatherHistory.csv.csv", header=0)
cells = args.cells
colour = ['GREEN', 'YELLOW', 'ORANGE', 'RED']
codes = pd.DataFrame(columns=cells)
maxWarn = []
for i in cells:

    data21 = weather21.loc[weather21['ID'] == i, ['WindS', 'Gust', 'Code']]
    data22 = weather22.loc[weather22['ID'] == i, ['WindS', 'Gust', 'Code']]
    data = pd.concat([data21, data22])
    data = data.dropna()
    data.reset_index(drop=True, inplace=True)
    pred = pd.DataFrame();
    for j in ['Gust', 'WindS']:
        mod = SARIMAX(data[j], order=(0, 1, 2), seasonal_order=(1, 0, 1, 6))
        res = mod.fit()
        prediction = res.forecast(steps=5).rename(j)
        pred = pd.concat([pred, prediction], axis=1)
    code = 0
    print(pred)
    pred.reset_index(inplace=True)
    for k in range(len(pred)):
        wind = pred.loc[k, 'WindS'] - 19
        gust = pred.loc[k, 'Gust'] - 40
        codes.loc[k, i] = max(0, wind // 8, gust // 10)
        code = max(code, wind // 8, gust // 10)
    maxWarn.append(code)
print(codes)

current = maxWarn[cells.index(args.loc)]
best = min(maxWarn)
if current == best:
    print('Stay at ' + args.loc)
else:
    print('Move from ' + args.loc + ' (code ' + colour[int(current)] + ') to ' + cells[
        maxWarn.index(int(best))] + ' (code ' + colour[int(best)] + ')')
