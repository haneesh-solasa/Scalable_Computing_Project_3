# ID,D,T,AtmPr,WindD,WindS,Gust,WaveH,WaveP,WaveD,Hmax,AirT,SeaT,Hum
import argparse
import pandas as pd

parser = argparse.ArgumentParser()
parser.add_argument('--report', help='Latest weather report', type=list)
args = parser.parse_args()

weather = pd.read_csv('weatherHistory.csv', header=0)
weather.iloc[weather.__len__()] = args.report
weather.to_csv('weatherHistory.csv',index=False)