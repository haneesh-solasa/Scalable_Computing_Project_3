# ID,LONG,LAT,D,T,AtmPr,WindD,WindS,Gust,WaveH,WaveP,WaveD,Hmax,AirT,SeaT,Hum
import argparse
import pandas as pd

parser = argparse.ArgumentParser()
parser.add_argument('--day', help='Day', type=int)
parser.add_argument('--time', help='Time', type=int)
parser.add_argument('--request', help='Request', type=str)
args = parser.parse_args()

weather = pd.read_csv("2022.csv", header=0)
ID = 'ID'
cols = args.request if args.request in weather.columns else weather.columns[:]

print(weather.loc[
          (weather['ID'] == args.ID) & (weather['D'] == args.day) & (weather['T'] == args.time), cols].values.tolist())
