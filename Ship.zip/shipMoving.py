# ID,D,T,AtmPr,WindD,WindS,Gust,WaveH,WaveP,WaveD,Hmax,AirT,SeaT,Hum
import argparse
import pandas as pd

parser = argparse.ArgumentParser()
parser.add_argument('--newLoc', help='Latest weather report', type=str)
args = parser.parse_args()

ship = pd.read_csv('shipData.csv', header=0)
ship.loc[0, 'location'] = args.newLoc
ship.to_csv('shipData.csv', index=False)
